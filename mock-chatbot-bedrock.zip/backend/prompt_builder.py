def build_prompt(user_query: str, gped_response: dict, business_reference_id: str) -> str:
    benefits = "\n".join([f"- {b['type']}: {b.get('amount') or b.get('code')}" for b in gped_response["benefits"]])
    ineligible = "\n".join([f"- {i['type']}: {i['reason']}" for i in gped_response["ineligible"]])

    return f"""
You are a smart and friendly customer support assistant.

User's message:
"{user_query}"

Here is the data from our backend for businessReferenceId {business_reference_id}:

✅ Eligible Benefits:
{benefits}

❌ Ineligible Benefits:
{ineligible}

Now, write a clear, friendly response to the user based on this data.
"""
