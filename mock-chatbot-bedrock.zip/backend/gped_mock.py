def get_mock_gped_response(business_reference_id: str):
    # Return simulated response
    return {
        "benefits": [
            {"type": "Cashback", "amount": "₹100"},
            {"type": "Coupon", "code": "SAVE20"}
        ],
        "ineligible": [
            {"type": "BonusPoints", "reason": "Order value < ₹499"},
            {"type": "Early Bird Offer", "reason": "Purchase was made after the offer deadline"}
        ]
    }
