from backend.gped_mock import get_mock_gped_response
from backend.prompt_builder import build_prompt
from config.bedrock_config import get_bedrock_client
import json
import re

def extract_business_reference_id(user_message: str):
    match = re.search(r"businessReferenceId\s*is\s*[\"']?([A-Za-z0-9-_]+)[\"']?", user_message, re.IGNORECASE)
    return match.group(1) if match else None

def handle_chat(user_message: str):
    business_id = extract_business_reference_id(user_message)
    if not business_id:
        return "Sorry, I couldn't find your businessReferenceId in the message."

    gped_response = get_mock_gped_response(business_id)
    prompt = build_prompt(user_message, gped_response, business_id)

    client = get_bedrock_client()
    body = {
        "prompt": prompt,
        "max_tokens_to_sample": 500,
        "temperature": 0.5
    }

    response = client.invoke_model(
        modelId="anthropic.claude-v2",
        contentType="application/json",
        accept="application/json",
        body=json.dumps(body)
    )

    result = json.loads(response['body'].read())
    return result["completion"]
