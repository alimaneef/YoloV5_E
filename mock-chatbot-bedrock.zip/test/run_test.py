from backend.chat_handler import handle_chat

with open("data/sample_user_query.txt", "r") as f:
    user_message = f.read()

response = handle_chat(user_message)
print("Final Bot Response:\n")
print(response)
