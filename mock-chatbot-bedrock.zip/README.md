# Mock Chatbot using AWS Bedrock

This project simulates a chatbot that takes a user query with a businessReferenceId, mocks a backend API response, and sends it to AWS Bedrock for a human-like answer.